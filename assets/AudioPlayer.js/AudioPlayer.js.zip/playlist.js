const tracks = [{
    title: 'Снова Я Напиваюсь',
    artist: "Slava Marlow",
    url: 'https://cdn1.sefon.pro/files/prev/196/Slava%20Marlow%20-%20%D0%A1%D0%BD%D0%BE%D0%B2%D0%B0%20%D0%AF%20%D0%9D%D0%B0%D0%BF%D0%B8%D0%B2%D0%B0%D1%8E%D1%81%D1%8C%20%28192kbps%29.mp3',
    cover: "https://cdn61.zvuk.com/pic?type=release&id=12513472&size=500x500&ext=jpg"
},{
    title: 'АУФ',
    artist: "SQWOZ BAB feat. The First Station",
    url: 'https://cdn1.sefon.pro/files/prev/199/SQWOZ%20BAB%20feat.%20The%20First%20Station%20-%20%D0%90%D0%A3%D0%A4%20%28192kbps%29.mp3',
    cover: "https://muzzona.info/uploads/posts/2020-10/1603349472_sqwoz-bab-feat_-the-first-station-auf.jpg"
},{
    title: 'Медляк',
    artist: "HammAli & Мари Краймбрери",
    url: 'https://cdn7.sefon.pro/files/prev/204/HammAli%20%26%20%D0%9C%D0%B0%D1%80%D0%B8%20%D0%9A%D1%80%D0%B0%D0%B9%D0%BC%D0%B1%D1%80%D0%B5%D1%80%D0%B8%20-%20%D0%9C%D0%B5%D0%B4%D0%BB%D1%8F%D0%BA%20%28192kbps%29.mp3',
    cover: "https://avatars.yandex.net/get-music-content/2411511/f4ee240c.a.12668304-1/m1000x1000"
}
];